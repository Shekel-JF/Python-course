Zestaw 1

Wersja Pythona: 3.9.13

Zadania 1, 3, 4 i 5 należy uruchomić komendą "python3 1.[numer zadania].py".
Dalsze instrukcje wyświetli program.

Zadanie 2 uruchomić komendą "python3 1.2.py" dopisując na końcu dowolne liczby dodatnie.
np. "python3 1.2.py 4407 13041599400"