A = set([3, 7, -5, 12, 21, 27, 81])
B = set([-2, 4, 7, 9, 13, -12, 27])

print('Pierwszy przyklad:')
print('zbior A = ', end = '')
print(A)
print('zbior B = ', end = '')
print(B)

print('\nCzesc wspolna zbiorow A i B: ')
print(A & B)

print('\nSuma zbiorow A i B: ')
print(A | B)

A = set([7, -2, 5, 128, 42])
B = set([42, 19, 53, 90, 5])

print('\n\nDrugi przyklad:')
print('zbior A = ', end = '')
print(A)
print('zbior B = ', end = '')
print(B)

print('\nCzesc wspolna zbiorow A i B: ')
print(A & B)

print('\nSuma zbiorow A i B: ')
print(A | B)